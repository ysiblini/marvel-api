package com.marvel.restapis.services;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CharactersServiceImplTest {

    @Autowired
    private CharactersService charactersService;

    @Test
    public void testGetCharactersIDs() throws IOException, NoSuchAlgorithmException {

        List expectedIds = new ArrayList() {
            {
                add("1011334");
                add("1017100");
                add("1009144");
                add("1010699");
                add("1009146");
                add("1016823");
                add("1009148");
                add("1009149");
                add("1010903");
                add("1011266");
                add("1010354");
                add("1010846");
                add("1011297");
                add("1011031");
                add("1009150");
                add("1011198");
                add("1011175");
                add("1011136");
                add("1011176");
                add("1010870");
            }};

        Assert.assertEquals(expectedIds, charactersService.getCharactersIDs());
    }

    @Test
    public void testGetCharacterWikiUrl() throws IOException, NoSuchAlgorithmException {
        String expectedWikiUrl = "http://marvel.com/universe/Warlock,_Adam?utm_campaign=apiRef&utm_source=4a39198e3d404d81cbda0d425cb5c202";
        Assert.assertEquals(expectedWikiUrl, charactersService.getCharacterWikiUrl("1010354"));
    }

    @Test
    public void testGetCharacterPowers() throws IOException, NoSuchAlgorithmException {
        List characterPowers = charactersService.getCharacterPowers("1011334");
        Assert.assertTrue(((String) characterPowers.get(0)).startsWith("The 3-D Man was"));
    }
}