package com.marvel.restapis.controllers;

import com.marvel.restapis.config.MarvelConfig;
import com.marvel.restapis.models.MarvelCharacter;
import com.marvel.restapis.services.CharactersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

@RestController
@RequestMapping("/characters")
public class CharactersController {

    @Autowired
    MarvelConfig marvelConfig;

    @Autowired
    CharactersService charactersService;

    @RequestMapping(method=RequestMethod.GET)
    public List<String> getChracters() throws IOException, NoSuchAlgorithmException {
         return charactersService.getCharactersIDs();
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public MarvelCharacter getCharacter(@PathVariable("id") String id) throws IOException, NoSuchAlgorithmException {
        return charactersService.getCharacterByID(id);
    }

    @RequestMapping(value = "/{id}/powers", method = RequestMethod.GET)
    public List<String> getCharacterPowers(@PathVariable("id") String id) throws IOException, NoSuchAlgorithmException {
        return charactersService.getCharacterPowers(id);
    }
}
