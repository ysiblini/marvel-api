package com.marvel.restapis.models;

public class MarvelCharacter {

    private String id;
    private String name;
    private String description;
    private Thumbnail thumbnail;

    public MarvelCharacter(String id, String name, String description, Thumbnail thumbnail) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.thumbnail = thumbnail;
    }

    public String getId() {
        return id;
    }
    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public Thumbnail getThumbnail() {
        return thumbnail;
    }


}
