package com.marvel.restapis.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource("classpath:app.properties")
public class MarvelConfig {

   @Value("${gateway.marvel.url}")
   private String gatewayUrl;

   @Value("${marvel.publicKey}")
   private String publicKey;

   @Value("${marvel.privateKey}")
   private String privateKey;

   public String getGatewayUrl() {
      return gatewayUrl;
   }

   public String getPublicKey() {
      return publicKey;
   }

   public String getPrivateKey() {
      return privateKey;
   }
}
