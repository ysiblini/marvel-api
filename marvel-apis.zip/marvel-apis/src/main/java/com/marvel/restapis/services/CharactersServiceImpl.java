package com.marvel.restapis.services;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.marvel.restapis.config.MarvelConfig;
import com.marvel.restapis.htmlparsing.ParsePowers;
import com.marvel.restapis.models.MarvelCharacter;
import com.marvel.restapis.models.Thumbnail;
import com.marvel.restapis.util.UrlHashUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

@Service
public class CharactersServiceImpl implements CharactersService {


    @Autowired
    MarvelConfig marvelConfig;

    private ParsePowers parsePowers = new ParsePowers();
    private static final Logger logger = LoggerFactory.getLogger(CharactersServiceImpl.class);
    protected static final long TIME_STAMP                           = System.currentTimeMillis();

    @Override
    public List<String> getCharactersIDs() throws IOException, NoSuchAlgorithmException {

        List listOfIDs = new ArrayList();
        String hash = UrlHashUtil.generateHash(String.valueOf(TIME_STAMP), marvelConfig.getPublicKey(), marvelConfig.getPrivateKey());
        final URL url = new URL(marvelConfig.getGatewayUrl() + "/characters?ts=" + TIME_STAMP + "&apikey=" + marvelConfig.getPublicKey() + "&hash=" + hash);

        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder result = getStringFromReader(rd);
        rd.close();

        JsonObject jsonObject = new JsonParser().parse(result.toString()).getAsJsonObject();
        JsonArray results = jsonObject.getAsJsonObject("data").getAsJsonArray("results");
        for (int i = 0; i < results.size(); i++)
            listOfIDs.add( results.get(i).getAsJsonObject().get("id").toString() );

        return listOfIDs;
    }

    @Override
    public MarvelCharacter getCharacterByID(String id) throws NoSuchAlgorithmException, IOException {

        String hash = UrlHashUtil.generateHash(String.valueOf(TIME_STAMP), marvelConfig.getPublicKey(), marvelConfig.getPrivateKey());
        final URL url = new URL(marvelConfig.getGatewayUrl() + "/characters/" + id +"?ts=" + TIME_STAMP + "&apikey=" + marvelConfig.getPublicKey() + "&hash=" + hash);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder result = getStringFromReader(rd);
        rd.close();

        JsonObject jsonObject = new JsonParser().parse(result.toString()).getAsJsonObject();
        JsonElement character = jsonObject.getAsJsonObject("data").getAsJsonArray("results").get(0);

        String characterId = character.getAsJsonObject().get("id").getAsString();
        String characterName = character.getAsJsonObject().get("name").getAsString();
        String characterDescription = character.getAsJsonObject().get("description").getAsString();

        String thumbnailPath = character.getAsJsonObject().get("thumbnail").getAsJsonObject().get("path").getAsString();
        String thumbnailExtension = character.getAsJsonObject().get("thumbnail").getAsJsonObject().get("extension").getAsString();
        Thumbnail thumbnail = new Thumbnail(thumbnailPath, thumbnailExtension);

        return new MarvelCharacter(characterId, characterName, characterDescription, thumbnail);
    }

    @Override
    public String getCharacterWikiUrl(String id) throws NoSuchAlgorithmException, IOException {

        String hash = UrlHashUtil.generateHash(String.valueOf(TIME_STAMP), marvelConfig.getPublicKey(), marvelConfig.getPrivateKey());
        final URL url = new URL(marvelConfig.getGatewayUrl() + "/characters/" + id +"?ts=" + TIME_STAMP + "&apikey=" + marvelConfig.getPublicKey() + "&hash=" + hash);

        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder result = getStringFromReader(rd);
        rd.close();

        JsonObject jsonObject = new JsonParser().parse(result.toString()).getAsJsonObject();
        JsonElement character = jsonObject.getAsJsonObject("data").getAsJsonArray("results").get(0);

        JsonArray urls = character.getAsJsonObject().getAsJsonArray("urls");

        for (int i = 0; i < urls.size(); i++) {
            if(urls.get(i).getAsJsonObject().get("type").getAsString().equals("wiki")) {
                return urls.get(i).getAsJsonObject().get("url").getAsString();
            }
        }

        return null;
    }

    @Override
    public List<String> getCharacterPowers(String characterId) throws IOException, NoSuchAlgorithmException {
        String characterWikiUrl = getCharacterWikiUrl(characterId);
        if (characterWikiUrl == null)
            logger.info("The character with the id: {} has no wiki URL", characterId);
        return parsePowers.getCharacterPowers(characterWikiUrl);
    }


    private StringBuilder getStringFromReader(BufferedReader rd) throws IOException {
        StringBuilder result = new StringBuilder();
        String line;
        while((line=rd.readLine())!=null)
            result.append(line);
        return result;
    }
}
