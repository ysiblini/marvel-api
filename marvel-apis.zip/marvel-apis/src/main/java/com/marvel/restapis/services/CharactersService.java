package com.marvel.restapis.services;

import com.marvel.restapis.models.MarvelCharacter;

import java.io.IOException;
import java.net.MalformedURLException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

public interface CharactersService {

    List<String> getCharactersIDs() throws IOException, NoSuchAlgorithmException;
    MarvelCharacter getCharacterByID(String id) throws NoSuchAlgorithmException, IOException;
    String getCharacterWikiUrl(String characterId) throws NoSuchAlgorithmException, IOException;
    List<String> getCharacterPowers(String characterId) throws IOException, NoSuchAlgorithmException;
}
