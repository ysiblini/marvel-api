package com.marvel.restapis.htmlparsing;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

@Component
public class ParsePowers {

    public List<String> getCharacterPowers(String wikiUrl) throws IOException, NoSuchAlgorithmException {

        Document doc = Jsoup.connect(wikiUrl).get();
        Elements texts = doc.getElementsByClass("text");
        List powers = new ArrayList();

        if (texts.size() == 1) {

            Elements paragraghs = texts.get(0).select("p");
            for (int i =0; i < paragraghs.size(); i++)
                powers.add(paragraghs.get(i).text());
        }

        return powers;

    }

}
